

    console.log(document.readyState);
    var id1 = document.getElementById("sticky-id-one"); 
    console.log("value is " + id1);
    id1.onmouseover = function() {
        console.log("hovered");
        document.getElementById("sticky-txt-one").classList.remove("ds-none");
    }
    id1.onmouseout = function() {
        document.getElementById("sticky-txt-one").classList.add("ds-none");
    }

    const id2 = document.getElementById("sticky-id-two"); 
    id2.onmouseover = function() {
        document.getElementById("sticky-txt-two").classList.remove("ds-none");
    }
    id2.onmouseout = function() {
        document.getElementById("sticky-txt-two").classList.add("ds-none");
    }

    const id3 = document.getElementById("sticky-id-three"); 
    id3.onmouseover = function() {
        document.getElementById("sticky-txt-three").classList.remove("ds-none");
    }
    id3.onmouseout = function() {
        document.getElementById("sticky-txt-three").classList.add("ds-none");
    }

    const id4 = document.getElementById("sticky-id-four"); 
    id4.onmouseover = function() {
        document.getElementById("sticky-txt-four").classList.remove("ds-none");
    }
    id4.onmouseout = function() {
        document.getElementById("sticky-txt-four").classList.add("ds-none");
    }


    const frd = document.getElementById("freedom");
    frd.onclick = function() {
        removeImgBlkClass();
        var imgblk1 = document.getElementById("img-block-img-one");
        var img1 = document.getElementById("img-block-one");
        var wrap1 = document.getElementById("img-block-wrap-one");
        if(frd.checked === true)
        {
            console.log("inside first");
            imgblk1.classList.add("img-block-selected");
            img1.classList.add("img-block-label");
            wrap1.classList.add("ds-no-op");
        }
}

    const nmarried = document.getElementById("newly-married");
    nmarried.onclick = function() {
        removeImgBlkClass();
        var imgblk2 = document.getElementById("img-block-img-two");
        var img2 = document.getElementById("img-block-two");
        var wrap2 = document.getElementById("img-block-wrap-two");
        if(nmarried.checked === true)
        {
            imgblk2.classList.add("img-block-selected");
            img2.classList.add("img-block-label");
            wrap2.classList.add("ds-no-op");

            console.log(imgblk2.classList);
        }
}

    const fbond = document.getElementById("family-bond");
    fbond.onclick = function () {
        removeImgBlkClass();
        var imgblk3 = document.getElementById("img-block-img-three");
        var img3 = document.getElementById("img-block-three");
        var wrap3 = document.getElementById("img-block-wrap-three");
        if(fbond.checked === true)
        {
            imgblk3.classList.add("img-block-selected");
            img3.classList.add("img-block-label");
            wrap3.classList.add("ds-no-op");
        }

}

    const gageing = document.getElementById("graceful-ageing");
    gageing.onclick = function() {
        removeImgBlkClass();
        var imgblk4 = document.getElementById("img-block-img-four");
        var img4 = document.getElementById("img-block-four");
        var wrap4 = document.getElementById("img-block-wrap-four");
        if(gageing.checked === true)
        {
            imgblk4.classList.add("img-block-selected");
            img4.classList.add("img-block-label");
            wrap4.classList.add("ds-no-op");
        }
}

var removeImgBlkClass = function () {

    var imgblk1 = document.getElementById("img-block-img-one");
    var img1 = document.getElementById("img-block-one");
    var wrap1 = document.getElementById("img-block-wrap-one");

    if(imgblk1.classList.length !== 0 && img1.classList.length !==0)
    {
        imgblk1.classList.remove("img-block-selected");
        img1.classList.remove("img-block-label");
        wrap1.classList.remove("ds-no-op");
        return;
    }

    var imgblk2 = document.getElementById("img-block-img-two");
    var img2 = document.getElementById("img-block-two");
    var wrap2 = document.getElementById("img-block-wrap-two");
    if(imgblk2.classList.length !== 0 && img2.classList.length !==0)
    {
        imgblk2.classList.remove("img-block-selected");
        img2.classList.remove("img-block-label");
        wrap2.classList.remove("ds-no-op");
        return;
    }

    var imgblk3 = document.getElementById("img-block-img-three");
    var img3 = document.getElementById("img-block-three");
    var wrap3 = document.getElementById("img-block-wrap-three");
    if(imgblk3.classList.length !== 0 && img3.classList.length !==0)
    {
        imgblk3.classList.remove("img-block-selected");
        img3.classList.remove("img-block-label");
        wrap3.classList.remove("ds-no-op");
        return;
    }

    var imgblk4 = document.getElementById("img-block-img-four");
    var img4 = document.getElementById("img-block-four");
    var wrap4 = document.getElementById("img-block-wrap-four");
    if(imgblk4.classList.length !== 0 && img4.classList.length !==0)
    {
        imgblk4.classList.remove("img-block-selected");
        img4.classList.remove("img-block-label");
        wrap4.classList.remove("ds-no-op");
    }
}

var obje1 = document.getElementById("managing-wealth");
var sel1 = document.getElementById("ins-obj-one");

obje1.onclick = function() {
    removeObjeClass();
    sel1.classList.add("ins-objective-select-repl-selected");
}

var obje2 = document.getElementById("pure-protection");
var sel2 = document.getElementById("ins-obj-two");

obje2.onclick = function() {
    removeObjeClass();
    sel2.classList.add("ins-objective-select-repl-selected");
}

const removeObjeClass = function() {
    var sel1 = document.getElementById("ins-obj-one");
    if(sel1.classList.length > 1)
    {
        sel1.classList.remove("ins-objective-select-repl-selected");
        return;
    }
    var sel2 = document.getElementById("ins-obj-two");
    if(sel2.classList.length > 1)
    {
        sel2.classList.remove("ins-objective-select-repl-selected");
    }
}

const showMenu = function() {
    var check = document.getElementById("menu-list-wrapper");
    if(check.classList.length > 1)
    {
        check.classList.remove("ds-none");
    }
}

const hideMenu = function() {
    document.getElementById("menu-list-wrapper").classList.add("ds-none");
}

const showForm = function() {
    var right = document.getElementById("mid-banner-right");
    right.classList.add("ds-none");
    var left = document.getElementById("left-form-box");
    left.classList.add("ds-initial");
}

const hideForm = function() {
    var right = document.getElementById("mid-banner-right");
    right.classList.remove("ds-none");
    var left = document.getElementById("left-form-box");
    left.classList.remove("ds-initial");
}
